package com.InternalDB.DPS;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InternalDbApplicationTests {

	@Test
	void contextLoads() {
	}

}
